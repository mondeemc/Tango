from os import environ as osenv
osenv['PYGAME_HIDE_SUPPORT_PROMPT'] = "True" #hide pygame welcome message
import pygame, sys, time, pyautogui, math, mouse, random

GRIDLENGTH = 3000
GRIDHEIGHT = 3000

def initialize():
    pygame.init()
    screenSize = (700,700)
    screen = pygame.display.set_mode(screenSize,pygame.RESIZABLE)
    #iconSurface = pygame.image.load('icon_some_bg.png')
    #pygame.display.set_icon(iconSurface)
    pygame.display.set_caption('Tango')
    return screen, screenSize

foregroundColour = (0,0,255)
#declare physics constants
moveSpeedConstant = 15 #constant by which the player accelerates in the x direction per frame of the movement key being held down
frictionConstant = 3 #constant by which the player decelerates
terminalVelocity = 50 #arbitrary values to limit player speed (probably important to avoid game breaking bugs)
bulletVelocity = 25
timeLastPress = time.time() # not constant
minDistShoot = 30 # constant for min shoot distance of cursor
cooldownShot = 1
hitBoxSize = 100
enemyMoveConstant = 10 #they're fast!


class Map:
    def __init__(self, objectList, enemyList, bulletList):
        self.objectList=objectList
        self.enemiesList=enemyList
        self.bulletsList=bulletList

class Player:
    def __init__(self, position, velocity):
        self.position=position
        self.velocity=velocity 

    def moveRight(self):
      self.velocity[0] -= moveSpeedConstant
      if self.velocity[0] < -1*terminalVelocity: #enforce negative terminal velocity
          self.velocity[0] = -1*terminalVelocity
    def moveLeft(self):
      self.velocity[0] += moveSpeedConstant
      if self.velocity[0] > terminalVelocity: #enforce terminal velocity
          self.velocity[0] = terminalVelocity
    def moveUp(self):
      self.velocity[1] += moveSpeedConstant
      if self.velocity[1] > terminalVelocity: #enforce terminal velocity
          self.velocity[1] = terminalVelocity
    def moveDown(self):
      self.velocity[1] -= moveSpeedConstant
      if self.velocity[1] < -1*terminalVelocity: #enforce negative terminal velocity
          self.velocity[1] = -1*terminalVelocity
    def collideX(self):
      self.velocity[0] = 0
    def collideY(self):
      self.velocity[1] = 0
    def tick(self): #update physics
        change = [0,0] #track change in position to move screen elements accordingly
        self.position[0] += self.velocity[0]
        change[0] += self.velocity[0]
        self.position[1] += self.velocity[1]
        change[1] += self.velocity[1]
        if self.velocity[0] > 0: #slow velocity X
            self.velocity[0] -= frictionConstant
            change[0] -= frictionConstant
        elif self.velocity[0] < 0:
            self.velocity[0] += frictionConstant
            change[0] += frictionConstant
        if self.velocity[1] > 0: #slow velocity Y
            self.velocity[1] -= frictionConstant
            change[1] -= frictionConstant
        elif self.velocity[1] < 0:
            self.velocity[1] += frictionConstant
            change[1] += frictionConstant
        return change
      
class Enemy:
    def __init__(self, positionEnemy, velocityEnemy,screenSize):
        self.position=positionEnemy
        self.velocity=velocityEnemy
        self.scrnSize = screenSize
    def tick(self,playerPosition):
        vx = self.scrnSize[0]-self.position[0]
        vy= self.scrnSize[1]-self.position[1]
        mag=math.sqrt(pow(vx,2) + pow(vy,2))
        vx = vx / mag
        vy = vy / mag #get unit vector
        #print("[", playerPosition[0], ", ", playerPosition[1],"]")
        self.position[0] -= vx*enemyMoveConstant
        self.position[1] -= vy*enemyMoveConstant
    
    def shift(self, direction):
        self.position[0] += direction[0]
        self.position[1] += direction[1]
        
class Bullet:
    def __init__(self, bulletPosition, bulletVelocity, bulletAngle,unitAimX,unitAimY):
       self.pos = bulletPosition
       self.vel = bulletVelocity
       self.ang = bulletAngle
       self.Vx = unitAimX
       self.Vy = unitAimY
       self.time = 0

    def tick(self):
       self.time+=1
       velX=self.vel * self.Vx
       velY=self.vel * self.Vy
       self.pos[0]+=velX
       self.pos[1]+=velY
       
    def shift(self, direction):
        self.pos[0] += direction[0]
        self.pos[1] += direction[1]

       
def spawnBullet(screenSize,bulletVelocity, bulletAngle, magnitude,timeLastPress,bulletSpawnPos,unitAimX,unitAimY):
    click=False
    click=mouse.is_pressed("left")
    timeElapsed=time.time()-timeLastPress
    #print("[",bulletSpawnPos[0],", ",bulletSpawnPos[1],"]")
    if (click == True) & (magnitude>30) & (timeElapsed>cooldownShot):
      timeLastPress=time.time()
      bullet1=Bullet([screenSize[0]/2,screenSize[1]/2],bulletVelocity,bulletAngle,unitAimX,unitAimY)
      return bullet1
    else:
        return False
   
def checkBulletCollision(listOfBullets,listOfEnemies):
    counterBullet=0
    counterEnemies=0
    while counterBullet<len(listOfBullets):
        bulletExist = False
        if len(listOfBullets)>0:
            bulletExist = True
        while counterEnemies<len(listOfEnemies):
            bulletPosX,bulletPosY=listOfBullets[counterBullet].pos
            enemyPosX,enemyPosY=listOfEnemies[counterEnemies].position
            if bulletExist == True:
                distEnemyBullet = math.sqrt(((enemyPosX-bulletPosX)**2)+((enemyPosY-bulletPosY)**2))
            print(distEnemyBullet)
            if (distEnemyBullet<hitBoxSize):
                del listOfBullets[counterBullet]
                del listOfEnemies[counterEnemies]
            counterEnemies+=1
        counterBullet+=1
    return listOfBullets,listOfEnemies

def findMouseVector(screenSize):
    playerPosX=screenSize[0]/2
    playerPosY=screenSize[1]/2
    mousePosX,mousePosY = pyautogui.position()
    aimVectorX=mousePosX-playerPosX
    aimVectorY=mousePosY-playerPosY
    magnitude=math.sqrt((aimVectorX**2)+(aimVectorY**2))
    unitAimX=aimVectorX/magnitude
    unitAimY=aimVectorY/magnitude
    try:
        if (aimVectorX<0) & (aimVectorY>0):
            degrees=180+(360*math.atan(aimVectorY/aimVectorX)/(2*math.pi))
        elif (aimVectorX<0) & (aimVectorY<0):
            degrees=180+(360*math.atan(aimVectorY/aimVectorX)/(2*math.pi))
        elif (aimVectorX>0) & (aimVectorY<0):
            degrees=360+(360*math.atan(aimVectorY/aimVectorX)/(2*math.pi))
        else:
            degrees=(360*math.atan(aimVectorY/aimVectorX)/(2*math.pi))
    except ZeroDivisionError:
        if aimVectorY>0:
            degrees=90
        elif aimVectorY<0:
            degrees=270
    return unitAimX, unitAimY, magnitude, degrees


def createEnemy(screenSize):
    if random.randint(0,100) < 3:
        #print("spawning enemy")
        x = random.randint(0,1500)
        y = random.randint(0,1500)
        enemy1=Enemy([x,y],[0,0],screenSize)
        return enemy1
    return False


def drawBg(screenSize,playerPos):
    
    screen.fill((0,0,0))

    #print(playerPos)

    positionX = -GRIDLENGTH - playerPos[0]
    positionY = -GRIDHEIGHT + playerPos[1]
    xTrue=True
    yTrue=True
    ctr=0
    while xTrue==True & yTrue==True:
        while xTrue==True & yTrue==True:
            xTrue=positionX<GRIDLENGTH
            if ctr % 2 == 0:
                pygame.draw.rect(screen, (50,50,50), (positionX, positionY, 10, 10))
                pygame.draw.rect(screen, (90,90,90), (positionX+10, positionY, 10, 10))
            else:
                pygame.draw.rect(screen, (90,90,90), (positionX, positionY, 10, 10))
                pygame.draw.rect(screen, (50,50,50), (positionX+10, positionY, 10, 10))
            positionX=positionX+20
        positionX=0 + playerPos[0]
        positionY=positionY+10
        xTrue=positionX<GRIDLENGTH
        yTrue=positionY<GRIDHEIGHT
        ctr=ctr+1

def drawWalls(listOfObjects): #draw walls / obstacles defined on map file
    counter = 0
    while counter < len(listOfObjects):
        objX1 = listOfObjects[counter][0] #[list of objects] --> [object] --> [x val]
        objY1 = listOfObjects[counter][1]
        objX2 = listOfObjects[counter][2]
        objY2 = listOfObjects[counter][3]
        pygame.draw.rect(screen,foregroundColour,(objX1,objY1,objX2,objY2))
        counter+=1

def drawEntities(listOfEnemies,listOfBullets): #draw moving things
    counter = 0 #draw enemies
    while counter < len(listOfEnemies):
        #objPos = listOfEnemies[counter].pos
        #pygame.draw.circle(screen, (255,40,40), objPos, 75) #TO DO TODO replace with surface image of enemy
        
        objPos = listOfEnemies[counter].position
        enemyImg = pygame.image.load("images/enemy.png")
        enemyImg = pygame.transform.scale(enemyImg, (50,50))
        
        posRect = enemyImg.get_rect(center= objPos )
        screen.blit(enemyImg, posRect)
        
        counter+=1
    
    counter = 0 #draw bullets
    while counter < len(listOfBullets):
        objPos = listOfBullets[counter].pos
        objAngle = listOfBullets[counter].ang
        bulletImg = pygame.image.load("images/laser.png")
        bulletImg = pygame.transform.scale(bulletImg, (50,50))
        
        posRect = bulletImg.get_rect(center= objPos )
        
        #pygame.transform.rotate(bulletImg,listOfBullets[counter].ang)
        
        screen.blit(pygame.transform.rotate(bulletImg,(listOfBullets[counter].ang + 50)* -1), posRect)
        
        #pygame.Surface.convert_alpha(bulletImg) 
        #pygame.draw.circle(screen, (3, 252, 252), objPos, 10) #TO DO TODO replace with surface image of bullet
        counter+=1
    
def drawPlayer(screenSize,mouseAngle):
    #pygame.draw.rect(screen,(0,255,150),((screenSize[0]/2),(screenSize[1]/2),20,20)) #replace with surface image! especially if it complains about screen surface being undefined.
    objPos = [screenSize[0]/2,screenSize[1]/2]
    playerImg = pygame.image.load("images/hero.png")
    playerImg = pygame.transform.scale(playerImg, (150,150))
    
    posRect = playerImg.get_rect(center= objPos )

    screen.blit(pygame.transform.rotate(playerImg,-1*(mouseAngle+90)), posRect)
    
def drawCrosshair():
    objPos = pyautogui.position()
    crosshairImg = pygame.image.load("images/blue_crosshair.png")
    crosshairImg = pygame.transform.scale(crosshairImg, (100,100))
    
    posRect = crosshairImg.get_rect(center= (objPos[0],objPos[1]-25) )
    
    screen.blit(crosshairImg, posRect)

def shiftAll(listOfObjects,listOfEnemies,listOfBullets,shiftVal): #Shift all objects along the axis (shiftVal = a list of 2: the amount to be shifted, pos or negative, for x and y.)
    counter = 0
    while counter < len(listOfObjects):

        listOfObjects[counter][0] += shiftVal[0]
        listOfObjects[counter][1] += shiftVal[1]

        counter +=1
    
    counter = 0
    while counter < len(listOfEnemies):

        listOfEnemies[counter].shift((shiftVal[0],shiftVal[1]))

        counter +=1
        
    counter = 0
    while counter < len(listOfBullets):

        listOfBullets[counter].shift((shiftVal[0],shiftVal[1]))

        counter +=1
    
    return listOfObjects,listOfEnemies,listOfBullets

def readMapFile(mapName): #Read the map file
    f = open("List Of GameMaps/"+str(mapName)+".txt","r")
    mapRawData = f.readlines()
    counter = 0
    while counter < 4: #process the first five metadata characters, which are not lists
            mapRawData[counter].strip()
            counter+=1
    while counter < len(mapRawData): #process the rest of the characters, which are lists
        counter2 = 0
        while counter2 < len(mapRawData[counter]):
            mapRawData[counter][counter2].strip() #clean data of any newline characters
            counter2 +=1
        
        counter +=1
        
        #FORMAT: (metadata:(floor height, start of map x coord, end of map x coord, starting player x coord),map data:(obj1(300,0,20,20,"Square"),obj2(350,0,20,20,"Square")))
    mapData = [[mapRawData[0],mapRawData[1],mapRawData[2],mapRawData[3]]]
    #NOTE^ above contains only metadata; next step is to append, to the outermost list, all object lists
    counter = 4 #start at 4 to skip the first 5 metadata lines
    while counter < len(mapRawData):
        splitData = mapRawData[counter].split(",")
        counter2 = 0
        while counter2 < len(splitData):
            if counter2+1 == len(splitData): #if on the last item of the datalist (which is a string such as "Square")
                splitData[counter2] = str(splitData[counter2])
            else:
                splitData[counter2] = int(splitData[counter2])
            counter2+=1
        mapData.append(splitData)
        
        counter +=1
    return mapData

def drawFrame(screenSize,gameData, mouseAngle):
    
    listOfObjects = gameData[0]
    listOfEnemies = gameData[1]
    listOfBullets = gameData[2]

    drawWalls(listOfObjects)
    drawEntities(listOfEnemies,listOfBullets)
    drawPlayer(screenSize,mouseAngle)
    drawCrosshair()
   
    pygame.display.flip()

def tick(screenSize,player,gameData,gridPosAdjust):
    unitAimX,unitAimY,magnitude,degrees=findMouseVector(screenSize)
    


    listOfObjects = gameData[0]
    listOfEnemies = gameData[1]
    listOfBullets = gameData[2]
    
    eVal = createEnemy(screenSize)
    if eVal != False:
        listOfEnemies.append(eVal)
    
    bulletSpawnPos = player.position
    temp = spawnBullet(screenSize,bulletVelocity,degrees,magnitude,timeLastPress,bulletSpawnPos,unitAimX,unitAimY)
    if temp != False:
        listOfBullets.append(temp)
        
    #iterate all bullets
    counter=0
    while counter<len(listOfBullets):
        listOfBullets[counter].tick()
        counter+=1
    
    #iterate all enemies
    counter=0
    while counter<len(listOfEnemies):
        listOfEnemies[counter].tick(player.position)
        counter+=1
    
    change = player.tick()
    listOfObjects,listOfEnemies,listOfBullets = shiftAll(listOfObjects,listOfEnemies,listOfBullets,change)
    gameData = listOfObjects,listOfEnemies,listOfBullets
    
    gridPosAdjust[0]+=change[0]
    gridPosAdjust[1]+=change[1]
    drawBg(screenSize, gridPosAdjust) #must be here, to keep track of adjustments

    listOfBullets,listOfEnemies=checkBulletCollision(listOfBullets,listOfEnemies)
    
    return gameData, gridPosAdjust, degrees

def liveView(initialScreenSize,mapName):
    
    screenSize = initialScreenSize
    running = True
    #drawFrame()
    
    mapData = readMapFile(mapName)
    listOfObjects = mapData[slice(2,len(mapData))] #start at 2 to skip metadata and the blankspace
    gameData = [listOfObjects,[],[]]
    player = Player([0,0],[0,0]) #initiate player object
    FPSlimit = 30 #30fps max
    secondsPerFrame = round((1/FPSlimit),3) #30fps roughly (1/30) rounded to the closest milisecond [3 d.p.]

    gridPosAdjust = [0,0] #for bg grid

    t0 = time.time() - secondsPerFrame #bypass the first fps limit check by instantly passing one frame's worth of time. allows instant start.
    while running:
        #try:
        if time.time() - t0 >= secondsPerFrame: #fps limiter
            #print("tick")
            t0 = time.time() #reset fps-limit timer
            
            #main loop body:
            gameData,gridPosAdjust,degrees = tick(screenSize,player,gameData,gridPosAdjust)
            drawFrame(screenSize,gameData,degrees)
            
            keys = pygame.key.get_pressed()
            if keys[100]: #d key
                #print("right")
                player.moveRight()
            if keys[97]: #a key
                #print("left")
                player.moveLeft() #move backwards
            if keys[119]: #w key
                player.moveUp()
            if keys[115]: #s key
                player.moveDown()
            
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.VIDEORESIZE:
                screenSize = screen.get_size()
            #elif event.type == pygame.KEYDOWN: #breaks the code.
        #except:
        #    print("CRITICAL ERROR [F-000]: Unable to display entity neural map for undetermined reason.")
    sys.exit()
    
#>>--Runspace:
screen,initialScreenSize = initialize()

f = open("Maps.txt", "r")
mapName = "map" + f.read()
f.close()
liveView(initialScreenSize,mapName)

