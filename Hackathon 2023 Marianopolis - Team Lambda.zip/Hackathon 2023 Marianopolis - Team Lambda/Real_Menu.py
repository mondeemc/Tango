# Import Section 
from tkinter import * 
from PIL import ImageTk, Image
import tkinter as tk
from tkinter import ttk
from playsound import playsound
import multiprocessing

playsound('main_screen_music.mp3',False)

#from Poop import root

# Creating the main window  
class Main_window: 
    def __init__(self): 

        # Creating a window 
        self.main_win = Tk() 

        # Define the geometry of the window
        self.main_win.geometry("600x300") 

        # Frame Stuff
        self.frame = Frame(self.main_win, width=400, height=600)
        self.frame.pack()
        self.frame.place(anchor='center', relx=0.5, rely=0.5)

        # Changing title of window 
        self.main_win.title("Menu")

        # Creating labels  
        self.win_name_label = Label(self.main_win, text="Menu", font=("Times", 45, "bold"))

        # Placing labels in window 
        self.win_name_label.grid(row=0, column=0, columnspan=5)

        # Creating button 
        self.play_button = Button(self.main_win, text="  Play   ", font=("Times", 15, "bold"), command=self.play_handler)
        self.setting_button = Button(self.main_win, text="Setting", font=("Times", 15, "bold"), command=self.open_sub_window)
        self.quit_button = Button(self.main_win, text="  Quit   ", font=("Times", 15, "bold"), command=self.quit_handler)
        self.map1_button = Button(self.main_win, text="  Map 1 ", font=("Times", 15, "bold"), command=self.map1_handler)
        self.map2_button = Button(self.main_win, text="  Map 2 ", font=("Times", 15, "bold"), command=self.map2_handler)
        self.map3_button = Button(self.main_win, text="  Map 3 ", font=("Times", 15, "bold"), command=self.map3_handler)

        # Placing button
        self.play_button.grid(row=1, column=0, columnspan=1)
        self.setting_button.grid(row=2, column=0, columnspan=1)
        self.quit_button.grid(row=3, column=0, columnspan=1)
        self.map1_button.grid(row=1, column=2, columnspan=1)
        self.map2_button.grid(row=2, column=2, columnspan=1)
        self.map3_button.grid(row=3, column=2, columnspan=1)

        # Create an object of tkinter ImageTk
        self.img = ImageTk.PhotoImage(Image.open("images/main_screen.png"))

        # Create a Label Widget to display the text or Image
        self.label = Label(self.frame, image = self.img)
        self.label.pack()

        # Displaying window 
        self.main_win.mainloop() 

    # Creating sub window method 
    def open_sub_window(self):
        root = tk.Tk()
        root.geometry('600x300')
        root.resizable(False, False)
        root.title('Settings')

        root.columnconfigure(0, weight=1)
        root.columnconfigure(1, weight=3)

        # slider current value
        current_value = tk.DoubleVar()

        def get_current_value():
            return '{: .2f}'.format(current_value.get())

        def slider_changed(event):
            value_label.configure(text=get_current_value())

        # label for the slider
        slider_label = ttk.Label(
            root,
            text='Volume:'
        )

        slider_label.grid(
            column=0,
            row=0,
            sticky='w'
        )

        #  slider
        slider = ttk.Scale(
            root,
            from_=0,
            to=100,
            orient='horizontal',  # vertical
            command=slider_changed,
            variable=current_value
        )

        slider.grid(
            column=1,
            row=0,
            sticky='we'
        )

        # current value label
        current_value_label = ttk.Label(
            root,
            text='Current Volume:'
        )

        current_value_label.grid(
            row=1,
            columnspan=2,
            sticky='n',
            ipadx=10,
            ipady=10
        )

        # value label
        value_label = ttk.Label(
            root,
            text=get_current_value()
        )
        value_label.grid(
            row=2,
            columnspan=2,
            sticky='n'
        )
        root.mainloop()

    # Creating play method 
    def play_handler(self):
        #close tkinter
        self.main_win.destroy()
        import main

    def map1_handler(self):
        self.main_win.destroy()
        file = open("Maps.txt", "w")  
        lines_1 = '1'
        file.write(lines_1)  
        file.close()
        import main

    def map2_handler(self):
        self.main_win.destroy()
        file = open("Maps.txt", "w")  
        lines_1 = '2'
        file.write(lines_1) 
        file.close()
        import main

    def map3_handler(self):
        self.main_win.destroy()
        file = open("Maps.txt", "w")  
        lines_1 = '3'
        file.write(lines_1) 
        file.close()
        import main

    # Creating quit method 
    def quit_handler(self): 
        self.main_win.destroy()
        #goop = tk.Tk()
        #goop.geometry('600x300')
        #img = ImageTk.PhotoImage(Image.open("main_screen.png"))
        #label = Label(self.frame, image = self.img)
        #label.pack()
        #goop.mainloop()

# Displaying window 
menu = Main_window() 
